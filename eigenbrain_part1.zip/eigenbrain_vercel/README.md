# 🧠 EigenBrain on Vercel

Brain tumor MRI classification (glioma, meningioma, pituitary tumor, no tumor) with PCA eigenbrains + SVM, and LDA class plots.
Trained on BRISC 2025: **94.5% accuracy** on 1,000 unseen test images.

> **Learning project, not a medical device. Not a diagnosis.**

## How it is built

```
Browser (public/index.html)  --POST image-->  /api/predict (api/predict.py, Python on Vercel)
        ^                                              |
        +---------- JSON: class, probabilities, --------+
                    LDA point, flags, reconstructions
```

| Folder / file | What it is |
|---|---|
| `public/` | the website (HTML + JS), sample images, plot data |
| `api/predict.py` | the serverless function that runs the model |
| `pipeline.py` | preprocessing + PCA/SVM/LDA prediction in plain numpy |
| `models/` | trained model as arrays (`model_a` to `model_d.npz`, each under 17 MB) + settings |
| `vercel.json`, `requirements.txt`, `.python-version` | Vercel settings (Python 3.12, numpy + opencv only) |
| `dev_server.py` | run the same site on your own PC |
| `train_export.py`, `export_numpy.py`, `make_static.py` | retraining tools (not deployed) |

Streamlit cannot run on Vercel (it needs a server that stays on), so this version uses a normal web page plus one API function.
The model uses numpy only (no scikit-learn) so the function stays small, about 270 MB (Vercel's limit for Python functions is 500 MB).
It was checked against the original scikit-learn model on all 1,000 test images: same top class every time, probability difference below 0.000002.

## Test on your PC first

```bash
pip install -r requirements.txt
python dev_server.py            # open http://localhost:8000
```

## Deploy

### Option A: Vercel CLI (fastest)
```bash
npm i -g vercel
cd eigenbrain_vercel
vercel login
vercel --prod
```
Answer the questions with the defaults (framework: **Other**). You get a link like `https://eigenbrain-xxxx.vercel.app`.

### Option B: GitHub
1. Put this folder in a new GitHub repo (the largest file is 47 MB, under GitHub's limit).
2. On vercel.com choose **Add New → Project**, import the repo, keep the defaults, click **Deploy**.

## Good to know

- **First request is slow** (a few seconds): the function loads the 47 MB model. After that it is fast (about 3 ms for the model itself).
- **Image size:** Vercel accepts request bodies up to about 4.5 MB. The page shrinks big photos in the browser before sending.
- **If the link asks you to log in to Vercel**, open the project on vercel.com, go to **Settings → Deployment Protection**, and turn it off so classmates can open it.
- The free Hobby plan is meant for personal, non-commercial projects, which fits a class project.

## Retrain (optional)

```bash
pip install -r requirements-train.txt
python train_export.py path/to/brisc2025     # trains, writes models/model.npz
python make_static.py                         # refreshes public/data/
```
