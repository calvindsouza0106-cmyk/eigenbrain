"""Run the whole site on your own PC (no Vercel needed):   python dev_server.py   ->  http://localhost:8000"""
import os, sys
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ROOT, "api"))
from predict import handler as ApiHandler          # the same code that Vercel runs

class Dev(SimpleHTTPRequestHandler):
    _json = ApiHandler._json
    def __init__(self, *a, **k):
        super().__init__(*a, directory=os.path.join(ROOT, "public"), **k)
    def do_POST(self):
        if self.path.split("?")[0] == "/api/predict": return ApiHandler.do_POST(self)
        self.send_error(404)
    def do_GET(self):
        if self.path.split("?")[0] == "/api/predict": return ApiHandler.do_GET(self)
        return super().do_GET()

if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    print(f"Open http://localhost:{port}")
    ThreadingHTTPServer(("", port), Dev).serve_forever()
