"""Creates the static data files used by the web page (run once after train_export.py)."""
import json, os
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pipeline import load_artifacts, IMG_SIZE

art = load_artifacts(); pca = art["pca"]; meta = art["meta"]
os.makedirs("public/data", exist_ok=True)
json.dump({"L": np.round(art["plot_L"], 3).tolist(), "y": art["plot_y"].tolist()}, open("public/data/lda_points.json", "w"))
json.dump(meta, open("public/data/meta.json", "w"))
fig, axs = plt.subplots(2, 6, figsize=(12, 4.4)); axs = axs.ravel()
axs[0].imshow(pca.mean_.reshape(IMG_SIZE, IMG_SIZE), cmap="bone"); axs[0].set_title("Mean brain", fontsize=10)
for i in range(10):
    axs[i + 1].imshow(pca.components_[i].reshape(IMG_SIZE, IMG_SIZE), cmap="bone")
    axs[i + 1].set_title(f"Eigenbrain {i+1}\n{pca.explained_variance_ratio_[i]*100:.1f}%", fontsize=9)
axs[11].axis("off")
for a in axs: a.set_xticks([]); a.set_yticks([])
plt.tight_layout(); plt.savefig("public/data/eigenbrains.png", dpi=110, bbox_inches="tight")
print("static files written")
