"""Turns the trained scikit-learn models (training_artifacts/*.joblib) into plain arrays (models/model.npz),
so the web function only needs numpy + opencv (much smaller, starts faster)."""
import os, joblib, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
A = os.path.join(HERE, "training_artifacts")
pca = joblib.load(os.path.join(A, "pca.joblib")); svm = joblib.load(os.path.join(A, "svm.joblib")); lda = joblib.load(os.path.join(A, "lda.joblib"))
probA = getattr(svm, "probA_", None); probB = getattr(svm, "probB_", None)
if probA is None or len(probA) == 0: probA, probB = svm._probA, svm._probB
np.savez(os.path.join(HERE, "models", "model.npz"),
         pca_mean=pca.mean_.astype(np.float32), pca_components=pca.components_.astype(np.float32),
         pca_var=pca.explained_variance_.astype(np.float64), pca_ratio=pca.explained_variance_ratio_.astype(np.float64),
         sv=svm.support_vectors_.astype(np.float64), n_support=svm.n_support_.astype(np.int64),
         dual_coef=svm.dual_coef_.astype(np.float64), intercept=svm.intercept_.astype(np.float64),
         prob_a=np.asarray(probA, dtype=np.float64), prob_b=np.asarray(probB, dtype=np.float64),
         gamma=np.float64(svm._gamma), lda_xbar=lda.xbar_.astype(np.float64), lda_scalings=lda.scalings_[:, :3].astype(np.float64))
print("model.npz written:", round(os.path.getsize(os.path.join(HERE, "models", "model.npz")) / 1e6, 1), "MB")
