"""Train the EigenBrain model on BRISC (needs scikit-learn) and write everything the website needs into models/.
After this run: python make_static.py   (page data) and copy 8 test images to public/samples/ if you want new samples.

Usage:  python train_export.py path/to/brisc2025
"""
import os, sys, glob, json, shutil, time
import numpy as np
import cv2, joblib
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix, classification_report
from pipeline import prep_gray, CLASSES, MODEL_DIR, structure_stats, maha_dist, MAHA_K

ROOT = sys.argv[1] if len(sys.argv) > 1 else "brisc2025"
for dp, dn, fn in os.walk(ROOT):                     # allow the parent folder too
    if "classification_task" in dn:
        ROOT = dp; break
CLS = os.path.join(ROOT, "classification_task")
K = 500                      # PCA components kept
CONF_THR = 0.60              # below this probability the app says "refer to a radiologist"
RNG = 42
os.makedirs(MODEL_DIR, exist_ok=True)
SK_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "training_artifacts")   # scikit-learn files (NOT deployed)
os.makedirs(SK_DIR, exist_ok=True)

def load(split):
    X, y, files = [], [], []
    for ci, c in enumerate(CLASSES):
        for f in sorted(glob.glob(os.path.join(CLS, split, c, "*.jpg"))):
            g = cv2.imread(f, 0)
            if g is None: continue
            X.append(prep_gray(g).ravel()); y.append(ci); files.append(f)
    return np.array(X, dtype=np.float32), np.array(y), files

t0 = time.time()
X, y, _ = load("train"); Xt, yt, ft = load("test")
print("loaded", X.shape, Xt.shape, "%.0fs" % (time.time() - t0))

# 90% to fit, 10% kept aside to set the safety thresholds
Xf, Xv, yf, yv = train_test_split(X, y, test_size=0.10, stratify=y, random_state=RNG)

pca = PCA(n_components=K, svd_solver="randomized", random_state=RNG).fit(Xf)
Zf, Zv, Zt = pca.transform(Xf), pca.transform(Xv), pca.transform(Xt)
svm = SVC(kernel="rbf", C=10, gamma="scale", probability=True, random_state=RNG).fit(Zf, yf)
lda = LDA(n_components=3).fit(Zf, yf)

# ---- test results
pred = svm.predict(Zt); proba = svm.predict_proba(Zt)
acc = accuracy_score(yt, pred); f1 = f1_score(yt, pred, average="macro")
print("TEST accuracy %.4f  macro-F1 %.4f" % (acc, f1))

# ---- safety thresholds
def recon_err(Z, Xs):
    rec = Z @ pca.components_ + pca.mean_
    return np.mean((Xs - rec) ** 2, axis=1)
err_val = recon_err(Zv, Xv)
err_thr = float(np.percentile(err_val, 99.5))                    # "does not look like our MRIs"
err_test = recon_err(Zt, Xt)
maha_val = np.array([maha_dist(pca, z) for z in Zv]); maha_thr = float(np.percentile(maha_val, 99.5))
sv = np.array([structure_stats(x) for x in Xv])
corner_max = float(np.percentile(sv[:, 0], 99.5))
fg_min, fg_max = float(np.percentile(sv[:, 1], 0.5)), float(np.percentile(sv[:, 1], 99.5))
st_t = np.array([structure_stats(x) for x in Xt]); maha_t = np.array([maha_dist(pca, z) for z in Zt])
flag_t = (err_test > err_thr) | (maha_t > maha_thr) | (st_t[:, 0] > corner_max) | (st_t[:, 1] < fg_min) | (st_t[:, 1] > fg_max)
conf = proba.max(axis=1); keep = conf >= CONF_THR
print("confidence >= %.2f: keeps %.1f%% of test images, accuracy on them %.4f" % (CONF_THR, 100 * keep.mean(), accuracy_score(yt[keep], pred[keep])))
print("test images flagged as 'not MRI-like': %.2f%%" % (100 * flag_t.mean()))
ok = ~flag_t & keep
print("accepted AND confident: keeps %.1f%% of test images, accuracy on them %.4f" % (100 * ok.mean(), accuracy_score(yt[ok], pred[ok])))

# ---- save models and small helper files
joblib.dump(pca, os.path.join(SK_DIR, "pca.joblib"), compress=3)
joblib.dump(svm, os.path.join(SK_DIR, "svm.joblib"), compress=3)
joblib.dump(lda, os.path.join(SK_DIR, "lda.joblib"), compress=3)

rs = np.random.RandomState(RNG)
idx = np.concatenate([rs.choice(np.where(yf == c)[0], min(400, (yf == c).sum()), replace=False) for c in range(4)])
np.savez_compressed(os.path.join(MODEL_DIR, "train_lda_points.npz"), L=lda.transform(Zf[idx]).astype(np.float32), y=yf[idx])

cm = confusion_matrix(yt, pred).tolist()
rep = classification_report(yt, pred, target_names=CLASSES, output_dict=True, digits=4)
meta = dict(k_components=K, variance_covered=float(pca.explained_variance_ratio_.sum()),
            confidence_threshold=CONF_THR, recon_err_threshold=err_thr,
            test_accuracy=float(acc), test_macro_f1=float(f1),
            maha_threshold=maha_thr, corner_max=corner_max, fg_min=fg_min, fg_max=fg_max, maha_k=MAHA_K,
            flagged_not_mri_test=float(flag_t.mean()), accepted_confident_coverage=float(ok.mean()),
            accepted_confident_accuracy=float(accuracy_score(yt[ok], pred[ok])),
            confident_coverage=float(keep.mean()), confident_accuracy=float(accuracy_score(yt[keep], pred[keep])),
            n_train=int(len(yf)), n_test=int(len(yt)), confusion_matrix=cm, report=rep, classes=CLASSES)
json.dump(meta, open(os.path.join(MODEL_DIR, "meta.json"), "w"), indent=1)

# ---- 2 random test images per class as demo samples (random, not picked by correctness)
os.makedirs("samples", exist_ok=True)
for f in glob.glob("samples/*"): os.remove(f)
for ci, c in enumerate(CLASSES):
    for f in list(rs.choice(np.array(ft)[yt == ci], 2, replace=False)):
        shutil.copy(f, os.path.join("samples", os.path.basename(f)))
import export_numpy   # writes models/model.npz (the file the website uses)
print("saved models:", {f: round(os.path.getsize(os.path.join(MODEL_DIR, f)) / 1e6, 1) for f in os.listdir(MODEL_DIR)}, "MB")
print("done in %.0fs" % (time.time() - t0))
