"""Vercel Python function: POST /api/predict  (body = raw bytes of a JPG/PNG)  ->  JSON result.
GET /api/predict -> small health check."""
import os, sys, json, base64
from http.server import BaseHTTPRequestHandler

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

import numpy as np
import cv2
from pipeline import load_artifacts, analyze, decode_image, reconstruct, IMG_SIZE, CLASSES

MAX_BYTES = 4_400_000                 # Vercel functions accept request bodies up to about 4.5 MB
STEPS = [5, 20, 50, 100, 250, 500]    # numbers of eigenbrains for the reconstruction slider
_ART = None


def get_art():
    """load the models once per warm function instance"""
    global _ART
    if _ART is None:
        _ART = load_artifacts()
    return _ART


def png_b64(img01):
    arr = (np.clip(img01, 0, 1) * 255).astype(np.uint8)
    ok, buf = cv2.imencode(".png", arr)
    return "data:image/png;base64," + base64.b64encode(buf.tobytes()).decode("ascii")


def build_response(art, gray):
    res = analyze(art, gray)
    steps = [n for n in STEPS if n <= art["meta"]["k_components"]]
    recs = {str(n): png_b64(reconstruct(art, res["z"], n)) for n in steps}
    return {
        "classes": CLASSES,
        "probs": [float(p) for p in res["probs"]],
        "top": res["top_name"],
        "confidence": res["confidence"],
        "confident": res["confident"],
        "looks_like_mri": res["looks_like_mri"],
        "reasons": res["reasons"],
        "lda_point": [float(v) for v in res["lda_point"]],
        "preprocessed": png_b64(res["x"].reshape(IMG_SIZE, IMG_SIZE)),
        "reconstructions": recs,
        "original_preprocessed_for_slider": png_b64(res["x"].reshape(IMG_SIZE, IMG_SIZE)),
    }


class handler(BaseHTTPRequestHandler):
    def _json(self, code, obj):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        try:
            m = get_art()["meta"]
            self._json(200, {"status": "ok", "test_accuracy": m["test_accuracy"], "k_components": m["k_components"]})
        except Exception as e:                      # model files missing, wrong library version, ...
            self._json(500, {"status": "error", "error": str(e)[:300]})

    def do_POST(self):
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        if length <= 0:
            return self._json(400, {"error": "Empty request. Send the image file as the request body."})
        if length > MAX_BYTES:
            return self._json(413, {"error": "Image is too large (limit about 4 MB). Please use a smaller image."})
        data = self.rfile.read(length)
        gray = decode_image(data)
        if gray is None:
            return self._json(400, {"error": "Could not read this file as an image. Please upload a JPG or PNG."})
        try:
            self._json(200, build_response(get_art(), gray))
        except Exception as e:
            self._json(500, {"error": "Prediction failed: " + str(e)[:200]})
