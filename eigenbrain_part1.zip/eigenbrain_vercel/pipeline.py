"""Preprocessing and prediction with numpy + opencv only (small and fast to start on Vercel)."""
import os, json
os.environ.setdefault("OPENCV_IO_MAX_IMAGE_PIXELS", str(40_000_000))   # refuse huge images (memory safety)
import numpy as np
import cv2

IMG_SIZE = 128
CLASSES = ["glioma", "meningioma", "no_tumor", "pituitary"]
PRETTY = {"glioma": "Glioma", "meningioma": "Meningioma", "no_tumor": "No tumor", "pituitary": "Pituitary tumor"}
MODEL_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")

_clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))


def prep_gray(g):
    """g = 2D array (any dtype). Returns float32 image in [0,1], IMG_SIZE x IMG_SIZE.
    Same steps as the notebook: median intensity scaling, resize, CLAHE."""
    g = g.astype(np.float32)
    head = g[g > 0.05 * g.max()] if g.max() > 0 else g.ravel()
    scale = np.median(head) if head.size else 1.0
    g = np.clip(g / (2 * scale + 1e-6), 0, 1)
    g = (g * 255).astype(np.uint8)
    g = cv2.resize(g, (IMG_SIZE, IMG_SIZE), interpolation=cv2.INTER_AREA)
    g = _clahe.apply(g)
    return g.astype(np.float32) / 255.0


def decode_image(file_bytes):
    """bytes of a jpg/png -> 2D grayscale uint8 array, or None if it cannot be read"""
    arr = np.frombuffer(file_bytes, dtype=np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_GRAYSCALE)
    if img is None or min(img.shape) < 32:
        return None
    return img


MAHA_K = 50      # number of leading PCA components used for the distance check


def structure_stats(x):
    """x = flat preprocessed image. Returns (corner brightness, foreground fraction).
    Real MRI slices have a dark background in the corners and the head fills a typical part of the frame."""
    im = x.reshape(IMG_SIZE, IMG_SIZE)
    c = 20
    corners = np.mean([im[:c, :c].mean(), im[:c, -c:].mean(), im[-c:, :c].mean(), im[-c:, -c:].mean()])
    return float(corners), float((im > 0.15).mean())


def maha_dist(pca, z_full, k=MAHA_K):
    """distance from the average training scan in PCA space, ~1 for a typical scan"""
    var = pca.explained_variance_[:k]
    return float(np.sqrt(np.sum(z_full[:k] ** 2 / var)) / np.sqrt(k))


class NpPCA:
    """PCA transform with plain numpy (same result as sklearn's PCA.transform)"""
    def __init__(self, d):
        self.mean_ = d["pca_mean"]; self.components_ = d["pca_components"]
        self.explained_variance_ = d["pca_var"]; self.explained_variance_ratio_ = d["pca_ratio"]
        self.n_components_ = self.components_.shape[0]

    def transform(self, X):
        return (X - self.mean_) @ self.components_.T


class NpLDA:
    """LDA transform with plain numpy (same result as sklearn's LDA.transform, svd solver)"""
    def __init__(self, d):
        self.xbar_ = d["lda_xbar"]; self.scalings_ = d["lda_scalings"]

    def transform(self, X):
        return (np.asarray(X, dtype=np.float64) - self.xbar_) @ self.scalings_


class NpSVM:
    """RBF-SVM probabilities with plain numpy, following libsvm (one-vs-one + Platt scaling + pairwise coupling)"""
    def __init__(self, d):
        self.sv = d["sv"]; self.n_support = d["n_support"]; self.coef = d["dual_coef"]; self.b = d["intercept"]
        self.A = d["prob_a"]; self.B = d["prob_b"]; self.gamma = float(d["gamma"])
        self.k = len(self.n_support)
        self.start = np.concatenate([[0], np.cumsum(self.n_support)])

    def _pairwise(self, z):
        kv = np.exp(-self.gamma * np.sum((self.sv - z) ** 2, axis=1))
        k, s, n, out, p = self.k, self.start, self.n_support, [], 0
        for i in range(k):
            for j in range(i + 1, k):
                ci = slice(s[i], s[i] + n[i]); cj = slice(s[j], s[j] + n[j])
                dec = kv[ci] @ self.coef[j - 1, ci] + kv[cj] @ self.coef[i, cj] + self.b[p]
                out.append(dec); p += 1
        return out

    def _couple(self, r):
        # libsvm multiclass_probability: iterate to combine the pairwise probabilities
        k = self.k
        Q = np.zeros((k, k)); p = np.full(k, 1.0 / k)
        for t in range(k):
            Q[t, t] = sum(r[j][t] ** 2 for j in range(k) if j != t)
            for j in range(k):
                if j != t: Q[t, j] = -r[j][t] * r[t][j]
        eps = 0.005 / k
        for _ in range(max(100, k)):
            Qp = Q @ p; pQp = p @ Qp
            if np.max(np.abs(Qp - pQp)) < eps: break
            for t in range(k):
                diff = (-Qp[t] + pQp) / Q[t, t]
                p[t] += diff
                pQp = (pQp + diff * (diff * Q[t, t] + 2 * Qp[t])) / (1 + diff) ** 2
                Qp = (Qp + diff * Q[t]) / (1 + diff)
                p /= (1 + diff)
        return p

    def predict_proba(self, Z):
        Z = np.atleast_2d(np.asarray(Z, dtype=np.float64)); res = []
        for z in Z:
            dec = self._pairwise(z); r = [[0.0] * self.k for _ in range(self.k)]; q = 0
            for i in range(self.k):
                for j in range(i + 1, self.k):
                    fab = dec[q] * self.A[q] + self.B[q]
                    pr = np.exp(-fab) / (1 + np.exp(-fab)) if fab >= 0 else 1.0 / (1 + np.exp(fab))
                    pr = min(max(pr, 1e-7), 1 - 1e-7)
                    r[i][j] = pr; r[j][i] = 1 - pr; q += 1
            res.append(self._couple(r))
        return np.array(res)


def load_artifacts():
    d = {}                                    # the model is stored in several small files (GitHub's web upload limit is 25 MB per file)
    for name in ("model_a.npz", "model_b.npz", "model_c.npz", "model_d.npz"):
        with np.load(os.path.join(MODEL_DIR, name)) as part:
            for k in part.files: d[k] = part[k]
    d["pca_components"] = np.concatenate([d.pop("pca_components_1"), d.pop("pca_components_2")], axis=0)
    d["sv"] = np.concatenate([d.pop("sv_1"), d.pop("sv_2")], axis=0)
    art = {"pca": NpPCA(d), "svm": NpSVM(d), "lda": NpLDA(d)}
    z = np.load(os.path.join(MODEL_DIR, "train_lda_points.npz"))
    art["plot_L"], art["plot_y"] = z["L"], z["y"]
    with open(os.path.join(MODEL_DIR, "meta.json")) as f:
        art["meta"] = json.load(f)
    return art


def analyze(art, gray_uint8):
    """Run the whole pipeline on one image. Returns a dict with everything the app shows."""
    meta = art["meta"]
    k = meta["k_components"]
    x = prep_gray(gray_uint8).ravel()
    z_full = art["pca"].transform(x.reshape(1, -1))
    z = z_full[:, :k]

    rec = z @ art["pca"].components_[:k] + art["pca"].mean_
    recon_err = float(np.mean((x - rec.ravel()) ** 2))

    probs = art["svm"].predict_proba(z)[0]
    order = np.argsort(probs)[::-1]
    top = int(order[0])
    lda_point = art["lda"].transform(z)[0]

    # four simple checks that the picture looks like the MRI slices the model was trained on
    maha = maha_dist(art["pca"], z_full[0])
    corner, fg = structure_stats(x)
    reasons = []
    if recon_err > meta["recon_err_threshold"]: reasons.append("cannot be rebuilt well from eigenbrains")
    if maha > meta["maha_threshold"]:           reasons.append("far from typical scans in PCA space")
    if corner > meta["corner_max"]:             reasons.append("background is not dark like an MRI")
    if fg < meta["fg_min"] or fg > meta["fg_max"]: reasons.append("head size in the frame is unusual")
    looks_like_mri = len(reasons) == 0
    confident = probs[top] >= meta["confidence_threshold"]
    return dict(x=x, z=z[0], probs=probs, top=top, top_name=CLASSES[top], confidence=float(probs[top]),
                recon_err=recon_err, reasons=reasons, looks_like_mri=bool(looks_like_mri), confident=bool(confident),
                lda_point=lda_point)


def reconstruct(art, z_full_row, n):
    """rebuild an image from its first n PCA components"""
    p = art["pca"]
    return (z_full_row[:n] @ p.components_[:n] + p.mean_).reshape(IMG_SIZE, IMG_SIZE)
